#include "atlimage.h"
#include "openssl/aes.h"

int encrypt_image(_TCHAR *infile, _TCHAR *outfile);

int _tmain(int argc, _TCHAR* argv[])
{
	if (argc < 3) {
		wprintf(L"Usage: ecb_encrypt_image [input BMP] [output BMP]\n");
		return 1;
	} else {
		return encrypt_image(argv[1], argv[2]);
	}
}

int encrypt_image(_TCHAR *infile, _TCHAR *outfile)
{
	CImage image;
	HRESULT hr;
	int height,width;
	COLORREF pixel_color;
	int x,y,i,j,i_buf,count;
	unsigned char data_in[16];
	unsigned char data_out[16];
	unsigned char key[32];
	AES_KEY aeskey;
		
	hr=image.Load(infile);
	if (hr==0)
	{
		height=image.GetHeight();
		width=image.GetWidth();
		// check if we can create 4x4 pixel blocks and encrypt these blocks
		if ((width%4!=0) || (height%4!=0)) {
			wprintf(L"Image width and length must be evenly divisible by 4; please resize image.\n");
			return -2;
		}

		memset(&key, 0, 32); // AES key of all 0's, change if you like

		AES_set_encrypt_key(key, 32*8, &aeskey);

		for (x=0;x<width;x=x+4)
		{
			for (y=0;y<height;y=y+4)
			{
				// read in 16 pixels
				count=0;
				for (i=x;i<x+4;i++)
				{
					for (j=y;j<y+4;j++)
					{
						pixel_color=image.GetPixel(i,j);
						i_buf=((int)GetRValue(pixel_color)+(int)GetGValue(pixel_color)+(int)GetBValue(pixel_color))/3;
						data_in[count]=(unsigned char)i_buf;
						count++;
					}
				}

				AES_encrypt(data_in, data_out, &aeskey);
				
				// write the 16 pixels back to the image
				count=0;
				
				for (i=x;i<x+4;i++)
				{
					for (j=y;j<y+4;j++)
					{
						image.SetPixelRGB(i,j,data_out[count],data_out[count],data_out[count]);
						count++;
					}
				}
			}
		}
		hr=image.Save(outfile);
		if (hr==0) {
			wprintf(L"Done.\n");
			return 0;
		} else {
			wprintf(L"Unable to create output image file.\n");
			return -1;
		}
	} else {
		wprintf(L"Unable to open input image file.\n");
		return -1;
	}
}